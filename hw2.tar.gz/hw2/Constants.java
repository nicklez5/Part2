class Constants{
    public static final String CLASS_TYPE = "CLASS";
    public static final String METHOD_TYPE = "METHOD";
    public static final String FIELD_TYPE = "FIELD";
    public static final String LOCAL_TYPE = "LOCAL";
    
}
